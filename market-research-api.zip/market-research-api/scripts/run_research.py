#!/usr/bin/env python3
"""
Market Research API Client Script
==================================
Execute market research tasks via the Market Research AI Platform API.

Usage:
    python run_research.py --request "研究需求" --api-key KEY [--api-base URL] [--personas N] [--output FILE]

Environment variables:
    MARKET_RESEARCH_API_KEY - API key for authentication
    MARKET_RESEARCH_API_BASE - API base URL (optional)
"""

import argparse
import json
import os
import sys
import time
import requests
from typing import Optional


def get_api_key() -> Optional[str]:
    """Get API key from environment or argument."""
    return os.environ.get("MARKET_RESEARCH_API_KEY")


def test_connection(api_base: str, api_key: str) -> dict:
    """Test API connection and return user info."""
    headers = {"Content-Type": "application/json", "X-API-Key": api_key}
    response = requests.get(f"{api_base}/auto-research/test", headers=headers)
    result = response.json()
    if result.get("code") != 0:
        raise Exception(f"API test failed: {result}")
    return result.get("data", {})


def submit_task(api_base: str, api_key: str, user_request: str, persona_count: int = 5, platforms: list = None) -> str:
    """Submit a research task and return task_id."""
    if platforms is None:
        platforms = ["小红书", "微博", "抖音"]
    
    headers = {"Content-Type": "application/json", "X-API-Key": api_key}
    payload = {
        "user_request": user_request,
        "persona_count": persona_count,
        "platforms": platforms
    }
    
    response = requests.post(
        f"{api_base}/auto-research/submit",
        headers=headers,
        json=payload
    )
    result = response.json()
    
    if result.get("code") != 0:
        raise Exception(f"Task submission failed: {result}")
    
    return result["data"]["task_id"]


def poll_status(api_base: str, api_key: str, task_id: str, interval: int = 5, max_wait: int = 600) -> dict:
    """Poll task status until completion or failure."""
    headers = {"Content-Type": "application/json", "X-API-Key": api_key}
    waited = 0
    
    while waited < max_wait:
        response = requests.get(
            f"{api_base}/auto-research/status/{task_id}",
            headers=headers
        )
        result = response.json()
        
        if result.get("code") != 0:
            raise Exception(f"Status check failed: {result}")
        
        data = result.get("data", {})
        status = data.get("status")
        
        if status == "completed":
            return {
                "status": "completed",
                "title": data.get("title"),
                "report": data.get("report")
            }
        elif status == "failed":
            raise Exception(f"Task failed: {data.get('error')}")
        elif status == "in_progress":
            phase = data.get("current_phase", "unknown")
            print(f"  [{waited}s] 执行中... 当前阶段: {phase}", file=sys.stderr)
        
        time.sleep(interval)
        waited += interval
    
    raise TimeoutError(f"Task timed out after {max_wait} seconds")


def main():
    parser = argparse.ArgumentParser(description="Market Research API Client")
    parser.add_argument("--request", "-r", required=True, help="Research request/topic")
    parser.add_argument("--api-key", "-k", help="API key (or set MARKET_RESEARCH_API_KEY env)")
    parser.add_argument("--api-base", "-b", default="http://localhost:8000/api/v1/research-flow",
                        help="API base URL")
    parser.add_argument("--personas", "-p", type=int, default=5, help="Number of personas (1-10)")
    parser.add_argument("--output", "-o", help="Output file for report (default: stdout)")
    parser.add_argument("--platforms", nargs="+", default=["小红书", "微博", "抖音"],
                        help="Social media platforms")
    parser.add_argument("--test", action="store_true", help="Test connection only")
    
    args = parser.parse_args()
    
    # Get API key
    api_key = args.api_key or get_api_key()
    if not api_key:
        print("Error: API key required. Set MARKET_RESEARCH_API_KEY or use --api-key", file=sys.stderr)
        sys.exit(1)
    
    # Test connection
    if args.test:
        info = test_connection(args.api_base, api_key)
        print(f"Connection OK")
        print(f"User: {info['user']['name']} ({info['user']['email']})")
        print(f"Credits: {info['user']['credits']}")
        print(f"Can research: {info['can_research']}")
        sys.exit(0)
    
    # Submit task
    print(f"Submitting research task...", file=sys.stderr)
    print(f"Request: {args.request}", file=sys.stderr)
    print(f"Personas: {args.personas}", file=sys.stderr)
    
    task_id = submit_task(
        args.api_base,
        api_key,
        args.request,
        args.personas,
        args.platforms
    )
    print(f"Task ID: {task_id}", file=sys.stderr)
    
    # Poll for results
    print(f"Waiting for completion...", file=sys.stderr)
    result = poll_status(args.api_base, api_key, task_id)
    
    # Output report
    report = result["report"]
    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(report)
        print(f"Report saved to: {args.output}", file=sys.stderr)
    else:
        print(report)


if __name__ == "__main__":
    main()
